-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2019 at 02:39 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ttms`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`` PROCEDURE `show` ()  NO SQL
SELECT name FROM classrooms
WHERE STATUS=0$$

CREATE DEFINER=`` PROCEDURE `tot` ()  NO SQL
SELECT COUNT(*) FROM teachers$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(30) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `password`) VALUES
('admin', 'pass123'),
('vivek', '1233210'),
('oh', '174e538b35'),
('ok', '81dc9bdb52');

-- --------------------------------------------------------

--
-- Table structure for table `classrooms`
--

CREATE TABLE `classrooms` (
  `name` varchar(30) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classrooms`
--

INSERT INTO `classrooms` (`name`, `status`) VALUES
('A241', 4),
('A348', 2),
('A243', 3),
('A244', 0),
('A123', 0),
('A232', 0),
('A344', 2),
('A345', 4),
('A346', 0);

-- --------------------------------------------------------

--
-- Table structure for table `semester3`
--

CREATE TABLE `semester3` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) NOT NULL,
  `period2` varchar(30) NOT NULL,
  `period3` varchar(30) NOT NULL,
  `period4` varchar(30) NOT NULL,
  `period5` varchar(30) NOT NULL,
  `period6` varchar(30) NOT NULL,
  `period7` varchar(20) NOT NULL,
  `period8` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester3`
--

INSERT INTO `semester3` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', 'AM261<br>SH', 'CO206<br>NA', 'EL211<br>MS', '-<br>-', '-<br>-', '-<br>-, -, -', '-<br>-', '-<br>-'),
('tuesday', 'CO203<br>SI', 'CO207<br>AMA', 'EL211<br>MS', 'AM261<br>SH', '-<br>-', 'CO293<br>SI, TA, IZ', '-<br>-', '-<br>-'),
('wednesday', 'CO206<br>NA', 'AM261<br>SH', 'CO207<br>AMA', '-<br>-', '-<br>-', 'CO292<br>AMA, MHK, FA', '-<br>-', '-<br>-'),
('thursday', 'CO203<br>SI', 'EL211<br>MS', 'CO207<br>AMA', '-<br>-', '-<br>-', 'CO293<br>SI, TA, IZ', '-<br>-', '-<br>-'),
('friday', 'CO206<br>NA', 'AM261<br>SH', 'CO203<br>SI', '-<br>-', '-<br>-', '-<br>-, -, -', '-<br>-', '-<br>-'),
('saturday', 'EL211<br>MS', 'CO207<br>AMA', 'CO203<br>SI', 'CO206<br>NA', '-<br>-', 'CO292<br>AMA, MHK, FA', '-<br>-', '-<br>-');

-- --------------------------------------------------------

--
-- Table structure for table `semester5`
--

CREATE TABLE `semester5` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) NOT NULL,
  `period2` varchar(30) NOT NULL,
  `period3` varchar(30) NOT NULL,
  `period4` varchar(30) NOT NULL,
  `period5` varchar(30) NOT NULL,
  `period6` varchar(30) NOT NULL,
  `period7` varchar(20) NOT NULL,
  `period8` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester5`
--

INSERT INTO `semester5` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', 'ME340<br>FT', '<--CN LAB(A1)', 'CO308<br>IZ', 'CO310<br>FA', '-<br>-', 'CO394<br>VG, MRW, AMA', '', ''),
('tuesday', 'EL340<br>MS', 'CO310<br>FA', 'ME340<br>FT', '-<br>-', '-<br>-', 'CO393<br>AMA, FA, RA', '', ''),
('wednesday', 'CO309<br>AMK', 'CO308<br>IZ', 'ME340<br>FT', '-<br>-', '-<br>-', '-<br>-, -, -', '', ''),
('thursday', 'EL340<br>MS', 'CO310<br>FA', 'CO309<br>AMK', '-<br>-', '-<br>-', 'CO393<br>AMA, FA, RA', '', ''),
('friday', 'CO308<br>IZ', 'ME340<br>FT', 'CO309<br>AMK', 'EL340<br>MS', '-<br>-', 'CO394<br>VG, MRW, AMA', '', ''),
('saturday', 'CO310<br>FA', 'EL340<br>MS', 'CO308<br>IZ', '-<br>-', '-<br>-', '-<br>-, -, -', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `semester7`
--

CREATE TABLE `semester7` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) NOT NULL,
  `period2` varchar(30) NOT NULL,
  `period3` varchar(30) NOT NULL,
  `period4` varchar(30) NOT NULL,
  `period5` varchar(30) NOT NULL,
  `period6` varchar(30) NOT NULL,
  `period7` varchar(20) NOT NULL,
  `period8` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester7`
--

INSERT INTO `semester7` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', 'CO445<br>MHK', 'CO431<br>RA', 'CO460<br>TA', '-<br>-', '-<br>-', 'CO494<br>IZ, MSU, SB', '', ''),
('tuesday', 'CO451<br>AMA', 'CO448<br>NA', 'CO406<br>AMA', 'CO445<br>MHK', '-<br>-', 'CO493<br>NA, MRW, AMK', '', ''),
('wednesday', 'CO431<br>RA', 'CO460<br>TA', 'CO445<br>MHK', 'CO451<br>AMA', 'CO448<br>NA', 'CO494<br>IZ, MSU, SB', '', ''),
('thursday', 'CO406<br>AMA', 'CO451<br>AMA', 'CO448<br>NA', 'CO431<br>RA', 'CO460<br>TA', 'CO493<br>NA, MRW, AMK', '', ''),
('friday', 'CO445<br>MHK', 'CO431<br>RA', 'CO460<br>TA', 'CO406<br>AMA', '-<br>-', '-<br>-, -, -', '', ''),
('saturday', 'CO451<br>AMA', 'CO448<br>NA', 'CO406<br>AMA', '-<br>-', '-<br>-', '-<br>-, -, -', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `course_type` varchar(15) NOT NULL,
  `semester` int(1) NOT NULL,
  `department` varchar(50) NOT NULL,
  `isAlloted` int(1) NOT NULL,
  `allotedto` text NOT NULL,
  `allotedto2` text NOT NULL,
  `allotedto3` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_code`, `subject_name`, `course_type`, `semester`, `department`, `isAlloted`, `allotedto`, `allotedto2`, `allotedto3`) VALUES
('17CS51', 'Management and Entrepreneurship for IT', 'THEORY', 5, 'Computer Engg. Dept.', 1, 'T003', '', ''),
('17CS52', 'Computer Network', 'THEORY', 5, 'Computer Engg. Dept.', 1, '', '', ''),
('17CS53', 'Database Management Systems', 'THEORY', 5, 'Computer Engg. Dept.', 1, 'T004', '', ''),
('18CSL37', 'Analog and Digital Electronics Laboratory', 'LAB', 3, 'Computer Engg. Dept.', 1, 'T013', 'T019', ''),
('17CS54', 'Automata Theory and Computability', 'THEORY', 5, 'Computer Engg. Dept.', 1, 'T002', '', ''),
('18CS35', 'Software Engineering', 'THEORY', 3, 'Computer Engg. Dept.', 1, 'T001', '', ''),
('18CSL38', ' Data Structures Lab', 'LAB', 3, 'Computer Engg. Dept.', 1, 'T014', 'T018', ''),
('17CS551', 'Professional Elective', 'THEORY', 5, 'Computer Engg. Dept.', 1, 'T006', '', ''),
('17CS562', 'Open Elective', 'THEORY', 5, 'Computer Engg. Dept.', 1, '', '', ''),
('17CSL57', 'Computer Network Lab', 'LAB', 5, 'Computer Engg. Dept.', 1, 'T003', '', ''),
('18CS34', 'Computer Organisation', 'THEORY', 3, 'Computer Engg. Dept.', 1, 'T018', '', ''),
('18CS36', 'Discret Mathematkical Structures', 'THEORY', 3, 'Computer Engg. Dept.', 1, 'T015', '', ''),
('18MAT31', 'Higher Mathematics', 'THEORY', 3, 'Applied Mathematics Dept.', 1, 't017', '', ''),
('18CS32', 'Data Structures & Application', 'THEORY', 3, 'Computer Engg. Dept.', 1, 'T014', '', ''),
('17CSL58', 'DBMS Laboratory with mini project', 'LAB', 5, 'Computer Engg. Dept.', 1, 'T004', '', ''),
('EL340', 'Communication Engineering', 'THEORY', 5, 'Electronics Engg. Dept.', 1, 'T014', '', ''),
('18CS33', 'Analog and Digital Electronics', 'THEORY', 3, 'Computer Engg. Dept.', 1, 'T013', '', ''),
('CO310', 'Operating Systems', 'THEORY', 5, 'Mechanical Engg. Dept.', 1, 'T013', '', ''),
('ME340', 'Economics & Management', 'THEORY', 5, 'Computer Engg. Dept.', 1, 'T015', '', ''),
('CO448', 'Embedded Systems', 'THEORY', 7, 'Computer Engg. Dept.', 1, 'T010', '', ''),
('CO460', 'Computer Architecture', 'THEORY', 7, 'Computer Engg. Dept.', 1, 'T009', '', ''),
('CO203', 'Object Oriented Programming', 'THEORY', 3, 'Computer Engg. Dept.', 1, 'T006', '', ''),
('co200', 'ds', 'THEORY', 3, 'Computer Engg.', 0, '', '', ''),
('18CPC39', 'Constitution of India, Professional Ethics and Hum', 'THEORY', 3, 'Computer Engg.', 1, 'T020', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t001`
--

CREATE TABLE `t001` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(20) NOT NULL,
  `period8` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t001`
--

INSERT INTO `t001` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '18CS35', '', ''),
('tuesday', '-<br>-', '-<br>-', '-<br>-', '18CS35', '-<br>-', '-', '-', '-'),
('wednesday', '18CS35', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('thursday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '-', '-'),
('friday', '-<br>-', '-<br>-', '18CS35', '-<br>-', '-<br>-', '-', '-', '-'),
('saturday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t002`
--

CREATE TABLE `t002` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(20) NOT NULL,
  `period8` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t002`
--

INSERT INTO `t002` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', 'CO206<br>A348', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('tuesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO493', '', ''),
('wednesday', 'CO206<br>A348', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('thursday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO493', '', ''),
('friday', 'CO206<br>A348', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('saturday', '-<br>-', '-<br>-', '-<br>-', 'CO206<br>A348', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t003`
--

CREATE TABLE `t003` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(20) NOT NULL,
  `period8` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t003`
--

INSERT INTO `t003` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO394', '', ''),
('tuesday', 'CO451<br>A241', 'CO207<br>A348', 'CO406<br>A241', '-<br>-', '-<br>-', 'CO393', '', ''),
('wednesday', '-<br>-', '-<br>-', 'CO207<br>A348', 'CO451<br>A241', '-<br>-', 'CO292', '', ''),
('thursday', 'CO406<br>A241', 'CO451<br>A241', 'CO207<br>A348', '-<br>-', '-<br>-', 'CO393', '', ''),
('friday', '-<br>-', '-<br>-', '-<br>-', 'CO406<br>A241', '-<br>-', 'CO394', '', ''),
('saturday', 'CO451<br>A241', 'CO207<br>A348', 'CO406<br>A241', '-<br>-', '-<br>-', 'CO292', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t004`
--

CREATE TABLE `t004` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(20) NOT NULL,
  `period8` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t004`
--

INSERT INTO `t004` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO494', '', ''),
('tuesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('wednesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO494', '', ''),
('thursday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('friday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('saturday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t006`
--

CREATE TABLE `t006` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t006`
--

INSERT INTO `t006` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('tuesday', 'CO203<br>A348', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO293', '', ''),
('wednesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('thursday', 'CO203<br>A348', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO293', '', ''),
('friday', '-<br>-', '-<br>-', 'CO203<br>A348', '-<br>-', '-<br>-', '-', '', ''),
('saturday', '-<br>-', '-<br>-', 'CO203<br>A348', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t007`
--

CREATE TABLE `t007` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t007`
--

INSERT INTO `t007` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO394', '', ''),
('tuesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO493', '', ''),
('wednesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('thursday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO493', '', ''),
('friday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO394', '', ''),
('saturday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t008`
--

CREATE TABLE `t008` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t008`
--

INSERT INTO `t008` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', '-<br>-', 'CO308<br>A243', '-<br>-', '-<br>-', 'CO494', '', ''),
('tuesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO293', '', ''),
('wednesday', '-<br>-', 'CO308<br>A243', '-<br>-', '-<br>-', '-<br>-', 'CO494', '', ''),
('thursday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO293', '', ''),
('friday', 'CO308<br>A243', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('saturday', '-<br>-', '-<br>-', 'CO308<br>A243', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t009`
--

CREATE TABLE `t009` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t009`
--

INSERT INTO `t009` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', '-<br>-', 'CO460<br>A241', '-<br>-', '-<br>-', '-', '', ''),
('tuesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO293', '', ''),
('wednesday', '-<br>-', 'CO460<br>A241', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('thursday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO460<br>A241', 'CO293', '', ''),
('friday', '-<br>-', '-<br>-', 'CO460<br>A241', '-<br>-', '-<br>-', '-', '', ''),
('saturday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t010`
--

CREATE TABLE `t010` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t010`
--

INSERT INTO `t010` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('tuesday', '-<br>-', 'CO448<br>A241', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('wednesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO448<br>A241', '-', '', ''),
('thursday', '-<br>-', '-<br>-', 'CO448<br>A241', '-<br>-', '-<br>-', '-', '', ''),
('friday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('saturday', '-<br>-', 'CO448<br>A241', '-<br>-', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t011`
--

CREATE TABLE `t011` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t011`
--

INSERT INTO `t011` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', 'CO309<br>A243', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('tuesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO493', '', ''),
('wednesday', 'CO309<br>A243', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('thursday', '-<br>-', '-<br>-', 'CO309<br>A243', '-<br>-', '-<br>-', 'CO493', '', ''),
('friday', '-<br>-', '-<br>-', 'CO309<br>A243', '-<br>-', '-<br>-', '-', '', ''),
('saturday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t012`
--

CREATE TABLE `t012` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t012`
--

INSERT INTO `t012` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', 'CO445<br>A241', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('tuesday', '-<br>-', '-<br>-', '-<br>-', 'CO445<br>A241', '-<br>-', '-', '', ''),
('wednesday', '-<br>-', '-<br>-', 'CO445<br>A241', '-<br>-', '-<br>-', 'CO292', '', ''),
('thursday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('friday', 'CO445<br>A241', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('saturday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO292', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t013`
--

CREATE TABLE `t013` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t013`
--

INSERT INTO `t013` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', '-<br>-', '-<br>-', 'CO310<br>A243', '-<br>-', '-', '', ''),
('tuesday', '-<br>-', 'CO310<br>A243', '-<br>-', '-<br>-', '-<br>-', 'CO393', '', ''),
('wednesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO292', '', ''),
('thursday', '-<br>-', 'CO310<br>A243', '-<br>-', '-<br>-', '-<br>-', 'CO393', '', ''),
('friday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('saturday', 'CO310<br>A243', '-<br>-', '-<br>-', '-<br>-', '-<br>-', 'CO292', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t014`
--

CREATE TABLE `t014` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t014`
--

INSERT INTO `t014` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', '-<br>-', '-<br>-', 'EL211<br>A348', '-<br>-', '-<br>-', '-', '', ''),
('tuesday', 'EL340<br>A243', '-<br>-', 'EL211<br>A348', '-<br>-', '-<br>-', '-', '', ''),
('wednesday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('thursday', 'EL340<br>A243', 'EL211<br>A348', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('friday', '-<br>-', '-<br>-', '-<br>-', 'EL340<br>A243', '-<br>-', '-', '', ''),
('saturday', 'EL211<br>A348', 'EL340<br>A243', '-<br>-', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t015`
--

CREATE TABLE `t015` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t015`
--

INSERT INTO `t015` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', 'ME340<br>A243', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('tuesday', '-<br>-', '-<br>-', 'ME340<br>A243', '-<br>-', '-<br>-', '-', '', ''),
('wednesday', '-<br>-', '-<br>-', 'ME340<br>A243', '-<br>-', '-<br>-', '-', '', ''),
('thursday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('friday', '-<br>-', 'ME340<br>A243', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('saturday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t016`
--

CREATE TABLE `t016` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) NOT NULL,
  `period8` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t016`
--

INSERT INTO `t016` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('monday', 'AM261<br>A348', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('tuesday', '-<br>-', '-<br>-', '-<br>-', 'AM261<br>A348', '-<br>-', '-', '', ''),
('wednesday', '-<br>-', 'AM261<br>A348', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('thursday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('friday', '-<br>-', 'AM261<br>A348', '-<br>-', '-<br>-', '-<br>-', '-', '', ''),
('saturday', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-<br>-', '-', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t019`
--

CREATE TABLE `t019` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) DEFAULT NULL,
  `period8` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t019`
--

INSERT INTO `t019` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('friday', '', '', '', '', '', '', '', ''),
('monday', '', '', '', '', '', '', '', ''),
('saturday', '', '', '', '', '', '', '', ''),
('thursday', '', '', '', '', '', '', '', ''),
('tuesday', '', '', '', '', '', '', '', ''),
('wednesday', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `t098`
--

CREATE TABLE `t098` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) DEFAULT NULL,
  `period8` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t567`
--

CREATE TABLE `t567` (
  `day` varchar(10) NOT NULL,
  `period1` varchar(30) DEFAULT NULL,
  `period2` varchar(30) DEFAULT NULL,
  `period3` varchar(30) DEFAULT NULL,
  `period4` varchar(30) DEFAULT NULL,
  `period5` varchar(30) DEFAULT NULL,
  `period6` varchar(30) DEFAULT NULL,
  `period7` varchar(10) DEFAULT NULL,
  `period8` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t567`
--

INSERT INTO `t567` (`day`, `period1`, `period2`, `period3`, `period4`, `period5`, `period6`, `period7`, `period8`) VALUES
('friday', '', '', '', '', '', '', '', ''),
('monday', '', '', '', '', '', '', '', ''),
('saturday', '', '', '', '', '', '', '', ''),
('thursday', '', '', '', '', '', '', '', ''),
('tuesday', '', '', '', '', '', '', '', ''),
('wednesday', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `faculty_number` varchar(10) NOT NULL,
  `name` text NOT NULL,
  `alias` varchar(10) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `emailid` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`faculty_number`, `name`, `alias`, `designation`, `contact_number`, `emailid`) VALUES
('T016', 'prof. Anu C.S', 'AC', 'Professor', '12345678', 'anu@gmail.com'),
('T015', 'prof. Gangadhar S', 'GA', 'Professor', '12345678', 'gan@gmail.com'),
('T014', 'prof. Naveen H.M.', 'NV', 'Professor', '12345678', 'naveen@gmail.com'),
('T013', 'prof. Naresh Patel K.M.', 'NP', 'Professor', '12345678', 'naresh@gmail.com'),
('T011', 'Dr. Vinutha H P', 'VN', 'Assistant Professor', '12345678', 'vin@gmail.com'),
('T012', 'Dr. Roopa G.M.', 'RP', 'Assistant Professor', '12345678', 'roopa@gmail.com'),
('T007', 'Dr. Pradeep N', 'PR', 'Associate Professor', '12345678', 'pradeep@gmail.com'),
('T008', 'Mr. S. B. Mallikarjuna', 'IZ', 'Associate Professor', '12345678', 'sb@gmail.com'),
('T009', 'prof. Naseer R', 'TA', 'Professor', '12345678', 'naseer@gmail.com'),
('T010', 'prof. Waseem Khan', 'NA', 'Professor', '12345678', 'waseem@gmail.com'),
('T006', 'prof. Arun kumar G Hiremath', 'SI', 'Professor', '12345678', 'arun@gmail.com'),
('T004', 'prof. Abdul Razak M.S', 'SB', 'Professor', '12345678', 'abdul@gmail.com'),
('T002', 'Dr. Ashoka K', 'NA', 'Professor', '12345678', 'ashoka@gmail.com'),
('T003', 'prof. Raghu B R', 'AMA', 'Professor', '12345678', 'raghu@gmail.com'),
('T001', 'Dr. Nirmala C R', 'MSU', 'Professor and Head', '12345678', 'nirmala@gmail.com'),
('T020', 'prof. Nijalingappa', 'NG', 'Professor', '123321', 'nij@123'),
('T017', 'Divya B', 'DB', 'Professor', '123321', 'divya@123'),
('T018', 'prof. Chaitra K C', 'CKC', 'Professor', '123321', 'chaitra@123'),
('T019', 'prof. Rashmi S h', 'RSH', 'Professor', '123321', 'rashmi@123'),
('t547', 'dg', 'd', 'profesor', '123333', 'sgfygs');

--
-- Triggers `teachers`
--
DELIMITER $$
CREATE TRIGGER `treddelete` BEFORE DELETE ON `teachers` FOR EACH ROW INSERT INTO trrig VALUES(OLD.faculty_number,OLD.name,'delete',now())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trigge` AFTER INSERT ON `teachers` FOR EACH ROW INSERT INTO trrig VALUES(NEW.faculty_number,NEW.name,'insert',now())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `triggupdate` AFTER UPDATE ON `teachers` FOR EACH ROW INSERT INTO trrig VALUES(NEW.faculty_number,NEW.name,'update',now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `trrig`
--

CREATE TABLE `trrig` (
  `teacher_id` varchar(20) NOT NULL,
  `name` varchar(11) NOT NULL,
  `action` varchar(20) NOT NULL,
  `date & time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trrig`
--

INSERT INTO `trrig` (`teacher_id`, `name`, `action`, `date & time`) VALUES
('t678', 'rivi', 'insert', '2019-11-21 06:44:36'),
('t678', 'rivi', 'update', '2019-11-21 06:45:04'),
('t678', 'rivi', 'delete', '2019-11-21 06:46:17'),
('T017', 'Divya B', 'update', '2019-11-21 10:22:57'),
('t987', 'ds', 'insert', '2019-11-21 10:35:27'),
('t987', 'ds', 'delete', '2019-11-21 10:36:04'),
('t547', 'dg', 'insert', '2019-11-21 12:17:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `semester3`
--
ALTER TABLE `semester3`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `semester5`
--
ALTER TABLE `semester5`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `semester7`
--
ALTER TABLE `semester7`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_code`);

--
-- Indexes for table `t001`
--
ALTER TABLE `t001`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t002`
--
ALTER TABLE `t002`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t003`
--
ALTER TABLE `t003`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t004`
--
ALTER TABLE `t004`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t006`
--
ALTER TABLE `t006`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t007`
--
ALTER TABLE `t007`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t008`
--
ALTER TABLE `t008`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t009`
--
ALTER TABLE `t009`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t010`
--
ALTER TABLE `t010`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t011`
--
ALTER TABLE `t011`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t012`
--
ALTER TABLE `t012`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t013`
--
ALTER TABLE `t013`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t014`
--
ALTER TABLE `t014`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t015`
--
ALTER TABLE `t015`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t016`
--
ALTER TABLE `t016`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t019`
--
ALTER TABLE `t019`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t098`
--
ALTER TABLE `t098`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `t567`
--
ALTER TABLE `t567`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`faculty_number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
