<?php

include 'connection.php';
if (isset($_POST['UU']) && isset($_POST['PP']) ) {
    $name = $_POST['UU'];
    $pas = $_POST['PP'];
   
    //  $message = "nTry again.";
    // echo "<script type='text/javascript'>alert('$message');</script>";
} else {
    $message = "dead.";
    echo "<script type='text/javascript'>alert('$message');</script>";
    die();
}
$q = mysqli_query(mysqli_connect("localhost", "root", "", "ttms"), "INSERT INTO admin VALUES ('$name','$pas')");
if ($q) {
    $message = "Username and password added.";
    echo "<script type='text/javascript'>alert('$message');</script>";
    
} else {
    $message = "please enter Username and Password.\\nTry again.";
    echo "<script type='text/javascript'>alert('$message');</script>";
     header("Location:index.php");

}
?>