<?php

3 session_start();
header ('location:login.php);

ndes

$con = mysqli_connect('localhost', 'root','123456');

mysqli select db ($in, 'user registration');

10

11

Name = $_POST['user'];
Space = $_POST['password'];

13
14
2345D7
15
16
17

$S = " select * from usertable where name '$name'"

Result = mysqli_query($con, $s);

$num = mysqli_num_rows($result);

18

19 if($num1) {
20 echo" Username Already Taken";
21 Jelse

22

$reg= " insert into user table(name, password) values ($name
23
mysqli_query ($con, $reg);
24
echo" Registration Successful";